import json
# import requests
from .Team import Team


class Competition:
    def __init__(self, par_id, par_name, par_code, par_area):
        self._id = par_id
        self.name = par_name
        self.code = par_code
        self.area = par_area
        #maak een lege list aan waarin straks de teams zullen bewaard worden
        self._teams = []

    #enkel een getter voor het ID (wis dus het set-gedeelte)
    @property
    def id(self):
        return self._id

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        if type(value) == str and value != "":
            self._name = value
        else:
            raise ValueError("Geen geldige name!")

    @property
    def code(self):
        return self._code

    @code.setter
    def code(self, value):
        if type(value) == str and value != "":
            self._code = value
        else:
            raise ValueError("Geen geldige code!")

    @property
    def area(self):
        return self._area

    @area.setter
    def area(self, value):
        if type(value) == str and value != "":
            self._area = value
        else:
            raise ValueError("Geen geldige area!")

    #enkel een getter --> Enkel opvragen kan. Je kan dus de list niet vervangen door een andere list        
    @property
    def teams(self):
        """The teams property."""
        return self._teams

    def __str__(self):
        #opm: het aantal teams bepaal je door de lengte van de list
        return f"Competition :{self.id} {self.name} {self.code} {self.area} - aantal teams {len(self.teams)} "

    #langs deze weg voegen we een team toe
    def voeg_team_toe(self, parteam):
        #controleer of het team al niet aanwezig is!
        if type(parteam) is Team and parteam not in self.teams:
            self._teams.append(parteam)
