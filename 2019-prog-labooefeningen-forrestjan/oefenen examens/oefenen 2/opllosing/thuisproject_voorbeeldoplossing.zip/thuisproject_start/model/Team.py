class Team:
    def __init__(self, par_name, par_shortname, par_founded, par_colors, par_venue):
        self.name = par_name
        self.shortname = par_shortname
        self.founded = par_founded
        self.colors = par_colors
        self.venue = par_venue

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        if type(value) == str and value != "":
            self._name = value
        else:
            raise ValueError("Geen geldige name!")

    @property
    def shortname(self):
        return self._shortname

    @shortname.setter
    def shortname(self, value):
        if type(value) == str and value != "":
            self._shortname = value
        else:
            raise ValueError("Geen geldige shortname!")

    @property
    def founded(self):
        return self._founded

    @founded.setter
    def founded(self, value):
        if type(value) == int and value > 0:
            self._founded = value
        else:
            raise ValueError("Geen geldige founded!")

    @property
    def colors(self):
        return self._colors

    @colors.setter
    def colors(self, value):
        if type(value) == str and value != "":
            self._colors = value
        else:
            raise ValueError("Geen geldige colors!")

    @property
    def venue(self):
        return self._venue

    @venue.setter
    def venue(self, value):
        if type(value) == str and value != "":
            self._venue = value
        else:
            raise ValueError("Geen geldige venue!")

    def __str__(self):
        return f"TEAM: {self.name} ({self.shortname}) Founded: {self.founded} {self.colors} {self.venue} "

    def __repr__(self):
        return f"TEAM: {self.shortname}"

    def __lt__(self, other):
        if self.shortname < other.shortname:
            return True
        else:
            return False

    def __eq__(self, other):
        if self.shortname == other.shortname:
            return True
        else:
            return False        
