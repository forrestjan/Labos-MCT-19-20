import json
# import requests
from .Competition import Competition
from .Team import Team


class CompetitionRepository:

    #LET OP MET HET PAD
    #
    _filename = "thuisproject_start/doc/uefa.json"

    @staticmethod
    def _read_local_json_file(bestandsnaam):
        fo = open(bestandsnaam, encoding="utf8")
        response_json = fo.read()
        fo.close()
        return json.loads(response_json)

    @staticmethod
    def load_competition():

        #kijk goed naar het json-bestand
        #het eerste karakter is een {   
        #dit wijst op een DICTIONARY

        dict_json = CompetitionRepository._read_local_json_file(CompetitionRepository._filename)  # local
        
        #neem het element competition vast: dit is opnieuw een dictionary!!!
        dict_comp = dict_json["competition"]
        temp_comp_naam = dict_comp["name"]
        temp_comp_code = dict_comp["code"]
        temp_comp_id = dict_comp["id"]

        #nog een niveau dieper --> opnieuw een dictionary!!!
        temp_comp_area = dict_comp["area"]
        temp_comp_area_name = temp_comp_area["name"]

        #ik maak hier al mijn object van de klasse Competition aan
        geladen_comp = Competition(
            temp_comp_id, temp_comp_naam, temp_comp_code, temp_comp_area_name)

        #En nu de teams....
        #ga naar de juiste plaats
        #je krijgt een list terug
        lst_teams = dict_json["teams"]

        #overloop de list
        #elk element in de list is opnieuw een dictionary!!!
        for team in lst_teams:
            try:
                #haal de nodige info op
                temp_name = team["name"]
                temp_shortname = team["shortName"]
                temp_club_colors = team["clubColors"]
                temp_founded = int(team["founded"])
                temp_venue = team["venue"]


                # team --> we maken gebruik van de klasse Team: maak object aan
                temp_team = Team(temp_name, temp_shortname,
                                 temp_founded, temp_club_colors, temp_venue)

                #voeg het team toe aan de competion-object                 
                geladen_comp.voeg_team_toe(temp_team)
            except Exception as ex:
                print(f"Foutmelding: {ex}")

        return geladen_comp

    
    @staticmethod
    def search_team_by_founded(parcompetition, parjaartal):
        #vraag de list teams op
        list_van_teams = parcompetition.teams
        #deze list zetten we klaar om op het einde terug te geven
        res_list = []
        #overloop de list teams
        for team in list_van_teams:
            if team.founded == parjaartal:
                res_list.append(team)
        return res_list #terug geven

    @staticmethod
    def search_team_by_clubcolor(parcompetition, parkleur):
        list_van_teams = parcompetition.teams
        res_list = []
        for team in list_van_teams:
            kleurstring = team.colors.lower()
            # if kleurstring in team.colors.lower()
            if kleurstring.find(parkleur) >= 0:
                res_list.append(team)
        return res_list
