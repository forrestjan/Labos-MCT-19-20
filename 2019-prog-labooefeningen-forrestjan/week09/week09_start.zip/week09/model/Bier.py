class Bier:

    def __init__(self, parnaam, parbrouwerij, paralcoholpercentage, parkleur):
        # hieronder maken we gebruik van de properties!
        self.naam = parnaam
        self.brouwerij = parbrouwerij
        self.alcoholpercentage = paralcoholpercentage
        self.kleur = parkleur

    @property
    def naam(self):
        return self._naam

    @naam.setter
    def naam(self, nieuwenaam):
        if (nieuwenaam != ""):
            self._naam = nieuwenaam.upper()
        else:
            self._naam = "onbekend"

    @property
    def brouwerij(self):
        return self._brouwerij

    @brouwerij.setter
    def brouwerij(self, nieuwebrouwerij):
        if (nieuwebrouwerij != ""):
            self._brouwerij = nieuwebrouwerij
        else:
            self._brouwerij = "onbekend"

    @property
    def alcoholpercentage(self):
        return self._alcoholpercentage

    @alcoholpercentage.setter
    def alcoholpercentage(self, nieuwalcoholpercentage):
        if type(nieuwalcoholpercentage) is float \
                and (nieuwalcoholpercentage >= 0) \
                and (nieuwalcoholpercentage <= 100):
            self._alcoholpercentage = nieuwalcoholpercentage
        else:
            self._alcoholpercentage = -1

    @property
    def kleur(self):
        return self._kleur

    @kleur.setter
    def kleur(self, nieuwkleur):
        if (nieuwkleur.strip() != ""):
            self._kleur = nieuwkleur
        else:
            self._kleur = "onbekend"

    def __str__(self):
        return f"{self.naam} {self.brouwerij} - {self.alcoholpercentage}"
