# importeer de correcte dataklasse


def test1():
    # bier = Bier("NMCT-Blond", "Howest", 25.0, "blond")
    # print(bier)
    pass

# test1()


def test2():
    pass


# test2()
